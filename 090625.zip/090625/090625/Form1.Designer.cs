﻿namespace _090625
{
    partial class frm_Entrada
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_nombre = new System.Windows.Forms.TextBox();
            this.lbl_nombre = new System.Windows.Forms.Label();
            this.btn_enviar = new System.Windows.Forms.Button();
            this.txt_estado = new System.Windows.Forms.TextBox();
            this.lst_paises = new System.Windows.Forms.ListBox();
            this.cmb_barrios = new System.Windows.Forms.ComboBox();
            this.Mc_Calendario1 = new System.Windows.Forms.MonthCalendar();
            this.dtp_calendario2 = new System.Windows.Forms.DateTimePicker();
            this.btn_abrirVentana = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_nombre
            // 
            this.txt_nombre.Location = new System.Drawing.Point(65, 33);
            this.txt_nombre.Name = "txt_nombre";
            this.txt_nombre.Size = new System.Drawing.Size(110, 20);
            this.txt_nombre.TabIndex = 0;
            // 
            // lbl_nombre
            // 
            this.lbl_nombre.AutoSize = true;
            this.lbl_nombre.Location = new System.Drawing.Point(65, 13);
            this.lbl_nombre.Name = "lbl_nombre";
            this.lbl_nombre.Size = new System.Drawing.Size(44, 13);
            this.lbl_nombre.TabIndex = 1;
            this.lbl_nombre.Text = "Nombre";
            // 
            // btn_enviar
            // 
            this.btn_enviar.Location = new System.Drawing.Point(65, 60);
            this.btn_enviar.Name = "btn_enviar";
            this.btn_enviar.Size = new System.Drawing.Size(75, 23);
            this.btn_enviar.TabIndex = 2;
            this.btn_enviar.Text = "Enviar";
            this.btn_enviar.UseVisualStyleBackColor = true;
            this.btn_enviar.Click += new System.EventHandler(this.btn_enviar_Click);
            // 
            // txt_estado
            // 
            this.txt_estado.Location = new System.Drawing.Point(353, 62);
            this.txt_estado.Name = "txt_estado";
            this.txt_estado.ReadOnly = true;
            this.txt_estado.Size = new System.Drawing.Size(164, 20);
            this.txt_estado.TabIndex = 3;
            // 
            // lst_paises
            // 
            this.lst_paises.FormattingEnabled = true;
            this.lst_paises.Items.AddRange(new object[] {
            "Argentina",
            "Brasil",
            "Chile"});
            this.lst_paises.Location = new System.Drawing.Point(353, 107);
            this.lst_paises.Name = "lst_paises";
            this.lst_paises.Size = new System.Drawing.Size(88, 56);
            this.lst_paises.TabIndex = 4;
            this.lst_paises.SelectedIndexChanged += new System.EventHandler(this.lst_paises_SelectedIndexChanged);
            // 
            // cmb_barrios
            // 
            this.cmb_barrios.FormattingEnabled = true;
            this.cmb_barrios.Items.AddRange(new object[] {
            "Almagro",
            "Boedo",
            "Caballito"});
            this.cmb_barrios.Location = new System.Drawing.Point(448, 107);
            this.cmb_barrios.Name = "cmb_barrios";
            this.cmb_barrios.Size = new System.Drawing.Size(121, 21);
            this.cmb_barrios.TabIndex = 5;
            this.cmb_barrios.SelectedIndexChanged += new System.EventHandler(this.cmb_barrios_SelectedIndexChanged);
            // 
            // Mc_Calendario1
            // 
            this.Mc_Calendario1.Location = new System.Drawing.Point(65, 95);
            this.Mc_Calendario1.Name = "Mc_Calendario1";
            this.Mc_Calendario1.TabIndex = 6;
            this.Mc_Calendario1.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.Mc_Calendario1_DateChanged);
            // 
            // dtp_calendario2
            // 
            this.dtp_calendario2.Location = new System.Drawing.Point(353, 180);
            this.dtp_calendario2.Name = "dtp_calendario2";
            this.dtp_calendario2.Size = new System.Drawing.Size(200, 20);
            this.dtp_calendario2.TabIndex = 7;
            this.dtp_calendario2.ValueChanged += new System.EventHandler(this.dtp_calendario2_ValueChanged);
            // 
            // btn_abrirVentana
            // 
            this.btn_abrirVentana.Location = new System.Drawing.Point(448, 206);
            this.btn_abrirVentana.Name = "btn_abrirVentana";
            this.btn_abrirVentana.Size = new System.Drawing.Size(131, 23);
            this.btn_abrirVentana.TabIndex = 8;
            this.btn_abrirVentana.Text = "abrir ventana";
            this.btn_abrirVentana.UseVisualStyleBackColor = true;
            this.btn_abrirVentana.Click += new System.EventHandler(this.btn_abrirVentana_Click);
            // 
            // frm_Entrada
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(584, 261);
            this.Controls.Add(this.btn_abrirVentana);
            this.Controls.Add(this.dtp_calendario2);
            this.Controls.Add(this.Mc_Calendario1);
            this.Controls.Add(this.cmb_barrios);
            this.Controls.Add(this.lst_paises);
            this.Controls.Add(this.txt_estado);
            this.Controls.Add(this.btn_enviar);
            this.Controls.Add(this.lbl_nombre);
            this.Controls.Add(this.txt_nombre);
            this.Name = "frm_Entrada";
            this.Text = "Aplicación 1.0";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_nombre;
        private System.Windows.Forms.Label lbl_nombre;
        private System.Windows.Forms.Button btn_enviar;
        private System.Windows.Forms.TextBox txt_estado;
        private System.Windows.Forms.ListBox lst_paises;
        private System.Windows.Forms.ComboBox cmb_barrios;
        private System.Windows.Forms.MonthCalendar Mc_Calendario1;
        private System.Windows.Forms.DateTimePicker dtp_calendario2;
        private System.Windows.Forms.Button btn_abrirVentana;
    }
}

