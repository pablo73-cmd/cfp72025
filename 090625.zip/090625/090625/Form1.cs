﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _090625
{
    public partial class frm_Entrada : Form
    {
        public frm_Entrada()
        {
            InitializeComponent();
        }

        private void btn_enviar_Click(object sender, EventArgs e)
        {
            if (txt_nombre.Text == "Pablo")
            {
                txt_estado.Text = txt_nombre.Text;

                txt_nombre.Text = "Sos profe";
            }
            else {
                txt_estado.Text = txt_nombre.Text;

                txt_nombre.Text = "Sos invitado";
            }
        }

        private void lst_paises_SelectedIndexChanged(object sender, EventArgs e)
        {
            txt_estado.Text = lst_paises.SelectedItem.ToString();
        }

        private void cmb_barrios_SelectedIndexChanged(object sender, EventArgs e)
        {
            txt_estado.Text = cmb_barrios.SelectedItem.ToString();
        }

        private void Mc_Calendario1_DateChanged(object sender, DateRangeEventArgs e)
        {
            txt_estado.Text = Mc_Calendario1.SelectionStart.DayOfWeek.ToString();
            if (txt_estado.Text == "Monday")
            {
                txt_estado.Text = "Lunes";
            }
        }

        private void dtp_calendario2_ValueChanged(object sender, EventArgs e)
        {
            txt_estado.Text = dtp_calendario2.Value.ToShortDateString();
        }

        private void btn_abrirVentana_Click(object sender, EventArgs e)
        {
            Form formu2 = new Form2();
            formu2.Show();
            this.Hide();
        }
    }
}
