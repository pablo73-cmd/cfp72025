﻿namespace _260925
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            btn_enviar = new Button();
            txt_emisor = new TextBox();
            lbl_receptor = new Label();
            chk_esclienteVIP = new CheckBox();
            cmb_paises = new ComboBox();
            dateTimePicker1 = new DateTimePicker();
            pictureBox1 = new PictureBox();
            btn_imagen = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // btn_enviar
            // 
            btn_enviar.Location = new Point(310, 127);
            btn_enviar.Name = "btn_enviar";
            btn_enviar.Size = new Size(75, 23);
            btn_enviar.TabIndex = 0;
            btn_enviar.Text = "enviar";
            btn_enviar.UseVisualStyleBackColor = true;
            btn_enviar.Click += btn_enviar_Click;
            // 
            // txt_emisor
            // 
            txt_emisor.Location = new Point(310, 91);
            txt_emisor.Name = "txt_emisor";
            txt_emisor.Size = new Size(128, 23);
            txt_emisor.TabIndex = 1;
            // 
            // lbl_receptor
            // 
            lbl_receptor.AutoSize = true;
            lbl_receptor.Location = new Point(543, 135);
            lbl_receptor.Name = "lbl_receptor";
            lbl_receptor.Size = new Size(0, 15);
            lbl_receptor.TabIndex = 2;
            // 
            // chk_esclienteVIP
            // 
            chk_esclienteVIP.AutoSize = true;
            chk_esclienteVIP.Location = new Point(600, 95);
            chk_esclienteVIP.Name = "chk_esclienteVIP";
            chk_esclienteVIP.Size = new Size(95, 19);
            chk_esclienteVIP.TabIndex = 3;
            chk_esclienteVIP.Text = "es cliente VIP";
            chk_esclienteVIP.UseVisualStyleBackColor = true;
            chk_esclienteVIP.CheckedChanged += chk_esclienteVIP_CheckedChanged;
            // 
            // cmb_paises
            // 
            cmb_paises.FormattingEnabled = true;
            cmb_paises.Items.AddRange(new object[] { "Argentina", "Brasil", "Chile" });
            cmb_paises.Location = new Point(39, 59);
            cmb_paises.Name = "cmb_paises";
            cmb_paises.Size = new Size(121, 23);
            cmb_paises.TabIndex = 4;
            cmb_paises.SelectedIndexChanged += cmb_paises_SelectedIndexChanged;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(524, 186);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(200, 23);
            dateTimePicker1.TabIndex = 5;
            dateTimePicker1.ValueChanged += dateTimePicker1_ValueChanged;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(39, 127);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(156, 130);
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // btn_imagen
            // 
            btn_imagen.Location = new Point(217, 186);
            btn_imagen.Name = "btn_imagen";
            btn_imagen.Size = new Size(197, 23);
            btn_imagen.TabIndex = 7;
            btn_imagen.Text = "mostrar / ocultar imagen";
            btn_imagen.UseVisualStyleBackColor = true;
            btn_imagen.Click += btn_imagen_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btn_imagen);
            Controls.Add(pictureBox1);
            Controls.Add(dateTimePicker1);
            Controls.Add(cmb_paises);
            Controls.Add(chk_esclienteVIP);
            Controls.Add(lbl_receptor);
            Controls.Add(txt_emisor);
            Controls.Add(btn_enviar);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btn_enviar;
        private TextBox txt_emisor;
        private Label lbl_receptor;
        private CheckBox chk_esclienteVIP;
        private ComboBox cmb_paises;
        private DateTimePicker dateTimePicker1;
        private PictureBox pictureBox1;
        private Button btn_imagen;
    }
}
