﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _260925
{
    public static class Comunicar
    {
        public static string? Comunicando { get; set; }
        public static bool Cliente { get; set; }

        public static string? Seleccion { get; set; }

        public static string? FechaSeleccionada { get; set; }
    
    public static bool estadoImagen { get; set; }

    } }