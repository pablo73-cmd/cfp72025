using System.Runtime.CompilerServices;

namespace _260925
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_enviar_Click(object sender, EventArgs e)
        {
            Comunicar.Comunicando = txt_emisor.Text;
            Form2 f2 = new Form2();
            f2.Show();
        }

        private void chk_esclienteVIP_CheckedChanged(object sender, EventArgs e)
        {
            Comunicar.Cliente = false;
            if (chk_esclienteVIP.Checked == true)
            {
                Comunicar.Cliente = true;

            }
        }

        private void cmb_paises_SelectedIndexChanged(object sender, EventArgs e)
        {
            Comunicar.Seleccion = cmb_paises.SelectedItem.ToString();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            Comunicar.FechaSeleccionada = dateTimePicker1.Value.DayOfYear.ToString();
            Form2 f2 = new Form2();
            f2.Show();
            this.Hide();
        }

        private void btn_imagen_Click(object sender, EventArgs e)
        {
            Comunicar.estadoImagen = pictureBox1.Visible;
            if (pictureBox1.Visible == false)
            {
                pictureBox1.Visible = true;
                Form2 f2 = new Form2();
                f2.Show();
                
            }
            else {
                pictureBox1.Visible = false;
                Form2 f2 = new Form2();
                f2.Show();
                

            }
         
        }
    }
}
