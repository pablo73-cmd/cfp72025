﻿namespace WindowsFormsApp3
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_nombre = new System.Windows.Forms.TextBox();
            this.btn_enviar = new System.Windows.Forms.Button();
            this.txt_estado = new System.Windows.Forms.TextBox();
            this.lst_paises = new System.Windows.Forms.ListBox();
            this.rb_escliente = new System.Windows.Forms.RadioButton();
            this.chk_VIP = new System.Windows.Forms.CheckBox();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.btn_abrirV = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_nombre
            // 
            this.txt_nombre.Location = new System.Drawing.Point(97, 69);
            this.txt_nombre.Name = "txt_nombre";
            this.txt_nombre.Size = new System.Drawing.Size(113, 20);
            this.txt_nombre.TabIndex = 0;
            // 
            // btn_enviar
            // 
            this.btn_enviar.Location = new System.Drawing.Point(232, 65);
            this.btn_enviar.Name = "btn_enviar";
            this.btn_enviar.Size = new System.Drawing.Size(75, 23);
            this.btn_enviar.TabIndex = 1;
            this.btn_enviar.Text = "env&iar";
            this.btn_enviar.UseVisualStyleBackColor = true;
            this.btn_enviar.Click += new System.EventHandler(this.btn_enviar_Click);
            // 
            // txt_estado
            // 
            this.txt_estado.Location = new System.Drawing.Point(97, 121);
            this.txt_estado.Name = "txt_estado";
            this.txt_estado.Size = new System.Drawing.Size(243, 20);
            this.txt_estado.TabIndex = 2;
            // 
            // lst_paises
            // 
            this.lst_paises.FormattingEnabled = true;
            this.lst_paises.Items.AddRange(new object[] {
            "Argentina",
            "Brasil",
            "Chile"});
            this.lst_paises.Location = new System.Drawing.Point(407, 36);
            this.lst_paises.Name = "lst_paises";
            this.lst_paises.Size = new System.Drawing.Size(120, 95);
            this.lst_paises.TabIndex = 3;
            this.lst_paises.SelectedIndexChanged += new System.EventHandler(this.lst_paises_SelectedIndexChanged);
            // 
            // rb_escliente
            // 
            this.rb_escliente.AutoSize = true;
            this.rb_escliente.Location = new System.Drawing.Point(407, 161);
            this.rb_escliente.Name = "rb_escliente";
            this.rb_escliente.Size = new System.Drawing.Size(71, 17);
            this.rb_escliente.TabIndex = 4;
            this.rb_escliente.TabStop = true;
            this.rb_escliente.Text = "Es cliente";
            this.rb_escliente.UseVisualStyleBackColor = true;
            this.rb_escliente.CheckedChanged += new System.EventHandler(this.rb_escliente_CheckedChanged);
            // 
            // chk_VIP
            // 
            this.chk_VIP.AutoSize = true;
            this.chk_VIP.Location = new System.Drawing.Point(407, 208);
            this.chk_VIP.Name = "chk_VIP";
            this.chk_VIP.Size = new System.Drawing.Size(76, 17);
            this.chk_VIP.TabIndex = 5;
            this.chk_VIP.Text = "cliente ViP";
            this.chk_VIP.UseVisualStyleBackColor = true;
            this.chk_VIP.Visible = false;
            this.chk_VIP.CheckedChanged += new System.EventHandler(this.chk_VIP_CheckedChanged);
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Location = new System.Drawing.Point(572, 36);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 6;
            this.monthCalendar1.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.monthCalendar1_DateChanged);
            // 
            // btn_abrirV
            // 
            this.btn_abrirV.Location = new System.Drawing.Point(618, 270);
            this.btn_abrirV.Name = "btn_abrirV";
            this.btn_abrirV.Size = new System.Drawing.Size(155, 46);
            this.btn_abrirV.TabIndex = 7;
            this.btn_abrirV.Text = "abrir nueva ventana";
            this.btn_abrirV.UseVisualStyleBackColor = true;
            this.btn_abrirV.Click += new System.EventHandler(this.btn_abrirV_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_abrirV);
            this.Controls.Add(this.monthCalendar1);
            this.Controls.Add(this.chk_VIP);
            this.Controls.Add(this.rb_escliente);
            this.Controls.Add(this.lst_paises);
            this.Controls.Add(this.txt_estado);
            this.Controls.Add(this.btn_enviar);
            this.Controls.Add(this.txt_nombre);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_nombre;
        private System.Windows.Forms.Button btn_enviar;
        private System.Windows.Forms.TextBox txt_estado;
        private System.Windows.Forms.ListBox lst_paises;
        private System.Windows.Forms.RadioButton rb_escliente;
        private System.Windows.Forms.CheckBox chk_VIP;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.Button btn_abrirV;
    }
}

