﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btn_mostrar_Click(object sender, EventArgs e)
        {
            pic_Vader.Visible = true;
        }

        private void mostrarImagenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pic_Vader.Visible = true;
        }

        private void cerrarProgramaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            Form j = new Form1();
            j.Show();
            this.Hide();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void cmb_personajes_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmb_personajes.SelectedItem.ToString() == "Darth Vader")
            {
                pic_Vader.Visible = true;
                pic_Mario.Visible = false;
            }
            else if (cmb_personajes.SelectedItem.ToString() == "Mario") {
                pic_Mario.Visible = true;
                pic_Vader.Visible = false;
            }
        }
    }
}
