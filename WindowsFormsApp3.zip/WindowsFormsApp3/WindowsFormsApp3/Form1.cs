﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_enviar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Esto es un texto", "Esto es un titulo", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);
            txt_estado.Text = txt_nombre.Text;
            txt_nombre.Text = "";
            txt_nombre.ReadOnly = true;

        }

        private void lst_paises_SelectedIndexChanged(object sender, EventArgs e)
        {
            txt_estado.Text = lst_paises.SelectedItem.ToString();
        }

        private void rb_escliente_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_escliente.Checked == true)
            {
                txt_estado.Text = "Es cliente";
                chk_VIP.Visible = true;
            }
        }

        private void chk_VIP_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_VIP.Checked == true) {
                txt_estado.Text = "Es cliente VIP";
            }
        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {
            txt_estado.Text = monthCalendar1.SelectionStart.DayOfYear.ToString();
        }

        private void btn_abrirV_Click(object sender, EventArgs e)
        {
            Form f = new Form2();
            f.Show();
            this.Hide();
        }
    }
}
