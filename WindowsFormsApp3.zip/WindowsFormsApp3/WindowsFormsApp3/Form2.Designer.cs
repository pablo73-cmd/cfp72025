﻿namespace WindowsFormsApp3
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.pic_Vader = new System.Windows.Forms.PictureBox();
            this.btn_mostrar = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.inicioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mostrarImagenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cerrarProgramaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.hToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cmb_personajes = new System.Windows.Forms.ComboBox();
            this.pic_Mario = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Vader)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Mario)).BeginInit();
            this.SuspendLayout();
            // 
            // pic_Vader
            // 
            this.pic_Vader.ContextMenuStrip = this.contextMenuStrip1;
            this.pic_Vader.Image = ((System.Drawing.Image)(resources.GetObject("pic_Vader.Image")));
            this.pic_Vader.Location = new System.Drawing.Point(498, 69);
            this.pic_Vader.Name = "pic_Vader";
            this.pic_Vader.Size = new System.Drawing.Size(272, 172);
            this.pic_Vader.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_Vader.TabIndex = 0;
            this.pic_Vader.TabStop = false;
            this.pic_Vader.Visible = false;
            // 
            // btn_mostrar
            // 
            this.btn_mostrar.Location = new System.Drawing.Point(557, 267);
            this.btn_mostrar.Name = "btn_mostrar";
            this.btn_mostrar.Size = new System.Drawing.Size(115, 23);
            this.btn_mostrar.TabIndex = 1;
            this.btn_mostrar.Text = "mostrar imagen";
            this.btn_mostrar.UseVisualStyleBackColor = true;
            this.btn_mostrar.Click += new System.EventHandler(this.btn_mostrar_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.inicioToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // inicioToolStripMenuItem
            // 
            this.inicioToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mostrarImagenToolStripMenuItem,
            this.cerrarProgramaToolStripMenuItem});
            this.inicioToolStripMenuItem.Name = "inicioToolStripMenuItem";
            this.inicioToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.inicioToolStripMenuItem.Text = "inicio";
            // 
            // mostrarImagenToolStripMenuItem
            // 
            this.mostrarImagenToolStripMenuItem.Name = "mostrarImagenToolStripMenuItem";
            this.mostrarImagenToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.mostrarImagenToolStripMenuItem.Text = "mostrar imagen";
            this.mostrarImagenToolStripMenuItem.Click += new System.EventHandler(this.mostrarImagenToolStripMenuItem_Click);
            // 
            // cerrarProgramaToolStripMenuItem
            // 
            this.cerrarProgramaToolStripMenuItem.Name = "cerrarProgramaToolStripMenuItem";
            this.cerrarProgramaToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.cerrarProgramaToolStripMenuItem.Text = "cerrar programa";
            this.cerrarProgramaToolStripMenuItem.Click += new System.EventHandler(this.cerrarProgramaToolStripMenuItem_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1});
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(800, 25);
            this.toolStrip1.TabIndex = 3;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton1.Text = "toolStripButton1";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(162, 26);
            // 
            // hToolStripMenuItem
            // 
            this.hToolStripMenuItem.Name = "hToolStripMenuItem";
            this.hToolStripMenuItem.Size = new System.Drawing.Size(161, 22);
            this.hToolStripMenuItem.Text = "hecho por Pablo";
            // 
            // cmb_personajes
            // 
            this.cmb_personajes.FormattingEnabled = true;
            this.cmb_personajes.Items.AddRange(new object[] {
            "Mario",
            "Luigi",
            "Donkey Kong",
            "Darth Vader"});
            this.cmb_personajes.Location = new System.Drawing.Point(53, 95);
            this.cmb_personajes.Name = "cmb_personajes";
            this.cmb_personajes.Size = new System.Drawing.Size(218, 21);
            this.cmb_personajes.TabIndex = 5;
            this.cmb_personajes.SelectedIndexChanged += new System.EventHandler(this.cmb_personajes_SelectedIndexChanged);
            // 
            // pic_Mario
            // 
            this.pic_Mario.Image = ((System.Drawing.Image)(resources.GetObject("pic_Mario.Image")));
            this.pic_Mario.Location = new System.Drawing.Point(498, 69);
            this.pic_Mario.Name = "pic_Mario";
            this.pic_Mario.Size = new System.Drawing.Size(272, 172);
            this.pic_Mario.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pic_Mario.TabIndex = 6;
            this.pic_Mario.TabStop = false;
            this.pic_Mario.Visible = false;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pic_Mario);
            this.Controls.Add(this.cmb_personajes);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.btn_mostrar);
            this.Controls.Add(this.pic_Vader);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pic_Vader)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pic_Mario)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pic_Vader;
        private System.Windows.Forms.Button btn_mostrar;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem inicioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mostrarImagenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cerrarProgramaToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem hToolStripMenuItem;
        private System.Windows.Forms.ComboBox cmb_personajes;
        private System.Windows.Forms.PictureBox pic_Mario;
    }
}